package com.myproject.postmaker;

import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiWorker extends Worker {

    public ApiWorker(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull
    @Override
    public Result doWork() {

        String mobileNumber = "7697549414";

        // Specify the API URL
        String apiUrl = "https://cloud.cypherx.in/";

        // Create Retrofit instance
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(apiUrl) // Base URL of the API
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        // Create ApiService instance
        ApiService apiService = retrofit.create(ApiService.class);

        // Create RequestBody instance
        RequestBody requestBody = new RequestBody(
                mobileNumber,
                0, // Set other variables as needed
                "90",
                0,
                0,
                "some_last_chunk_download_time"
        );

        // Make the POST request
        Call<Void> call = apiService.register(requestBody);

        try {
            Response<Void> response = call.execute();
            Log.d("ApiWorker", "doWork: Executing...");
            if (response.isSuccessful()) {
                Log.d("ApiWorker", "doWork: Success");
                return Result.success();
            } else {
                Log.e("ApiWorker", "doWork: Unsuccessful response");
                return Result.failure();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Log.e("ApiWorker", "doWork: Exception - " + e.getMessage());
            return Result.failure();
        }
    }
}


