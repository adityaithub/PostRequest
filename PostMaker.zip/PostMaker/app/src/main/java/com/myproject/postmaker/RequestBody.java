package com.myproject.postmaker;

import org.jetbrains.annotations.Nullable;

import java.io.IOException;

import okhttp3.MediaType;
import okio.BufferedSink;

public class RequestBody  {

    private String node_id_;
    private long network_speed_;
    private String battery_status;
    private long free_bytes;
    private long used_bandwidth;
    private String last_chunk_download_time;

    public RequestBody(String node_id_, long network_speed_, String battery_status, long free_bytes,
                       long used_bandwidth, String last_chunk_download_time) {
        this.node_id_ = node_id_;
        this.network_speed_ = network_speed_;
        this.battery_status = battery_status;
        this.free_bytes = free_bytes;
        this.used_bandwidth = used_bandwidth;
        this.last_chunk_download_time = last_chunk_download_time;
    }


}

