package com.myproject.postmaker;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface ApiService {

    @POST("register")
    Call<Void> register(@Body RequestBody requestBody);
}

